<template>
    <footer class="bg-gray-100 h-16 w-full items-center flex mt-4">
            <div class="container mx-auto">
                <div class="flex justify-between">
                    <p>© Idea Bubble 2008 to 2022</p>
                    <p>Powered by Ideabubble Engine c2886a0 Testing c2886a0</p>
                    <p>Show Profiler</p>
                </div>
            </div>
    </footer>
</template>

<script>
export default {
    name: 'Footer',

    methods: {}
}
</script>

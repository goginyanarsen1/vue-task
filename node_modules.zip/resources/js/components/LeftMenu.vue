<template>
    <div class="flex flex-col bg-gray-100">
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-home"></i>
            <span class="ml-2">Home</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-file-invoice"></i>
            <span class="ml-2">Accounts</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="far fa-file-alt"></i>
            <span class="ml-2">Attendance</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="far fa-bell"></i>
            <span class="ml-2">Automations</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-ticket-alt"></i>
            <span class="ml-2">Bookings</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-users"></i>
            <span class="ml-2">Contacts</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-book"></i>
            <span class="ml-2">Courses</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-tachometer-alt"></i>
            <span class="ml-2">Dashboards</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-folder-open"></i>
            <span class="ml-2">Files</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>

        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-play"></i>
            <span class="ml-2">Files</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>

        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-bars"></i>
            <span class="ml-2">Menus</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-comment "></i>
            <span class="ml-2">Messaging</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-newspaper"></i>
            <span class="ml-2">News</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-bell "></i>
            <span class="ml-2">Notifications</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-pager"></i>
            <span class="ml-2">Pages</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-columns"></i>
            <span class="ml-2">Panels</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-tasks"></i>
            <span class="ml-2">Questionnaires</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-chart-line"></i>
            <span class="ml-2">Reports</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-poll-h"></i>
            <span class="ml-2">Surveys</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-star"></i>
            <span class="ml-2">Testimonials</span>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-globe-asia"></i>
            <span class="ml-2">Timeoff</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="far fa-calendar"></i>
            <span class="ml-2">Timesheets</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-calendar"></i>
            <span class="ml-2">Timetables</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>
        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary border-b">
            <i class="fas fa-calendar-check"></i>
            <span class="ml-2">Todos</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>

        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-cog"></i>
            <span class="ml-2">Settings</span>
        </div>

        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-user-alt"></i>
            <span class="ml-2">Profile</span>
            <i class="fas fa-angle-right ml-2"></i>
        </div>

        <div class="flex items-center px-4 py-2 cursor-pointer hover:text-white hover:bg-primary text-primary">
            <i class="fas fa-sign-out-alt"></i>
            <span class="ml-2">
                <router-link to="login" >Log out</router-link>
            </span>
        </div>


    </div>
</template>

<script>
export default {
    name: 'LeftMenu',

    methods: {}
}
</script>
